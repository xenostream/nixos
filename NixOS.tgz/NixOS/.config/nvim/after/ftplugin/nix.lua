-- ~/.config/nvim/after/ftplugin/nix.lua
local set = vim.opt_local

set.shiftwidth = 2
set.tabstop = 2
set.softtabstop = 2
set.expandtab = true

-- extras you want for Nix buffers
set.number = true
set.relativenumber = true
