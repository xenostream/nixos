source ~/.vim/options.vim
source ~/.vim/keybinds.vim
source ~/.vim/plugins.vim
source ~/.vim/colors.vim
source ~/.vim/fzf.vim
source ~/.vim/lightline.vim
"source ~/.vim/lsp.vim
